PYARUBAIMC Python project
=======================

A sample project that exists as an aid for aruba IMC customers to access the RESTFUL API (eAPI) of the Network Management
System Natively from within python.

For example usages, please see the

This project is offered under and Apache2 license and is not supported officially by aruba.

For more information, please visit the project home page at `GITHub.com <https://github.com/arubaNetworking/PYarubaIMC>`_.


What's Changed:

0.1.0 Initial Release

0.1.1 Fixed import under __inity__.py file    RK 04212022

0.1.3 Fixed import under __inity__.py file    RK 04212022
